package com.example.appwithsettings;

public class SettingActivity {


}
