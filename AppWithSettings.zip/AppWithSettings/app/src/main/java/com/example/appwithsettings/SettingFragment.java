package com.example.appwithsettings;

public class SettingFragment {
}
